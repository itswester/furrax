Komet -> MAX: список чатов, иконка, название

Как применить к своему форку:
1) Распакуй архив в корень форка с заменой файлов (папки lib/, ios/, assets/ ляжут поверх).
   Либо: git apply changes.patch
2) Закоммить и запушь.
3) GitHub -> Actions -> Build iOS -> Run workflow.
4) Скачай артефакт komet-ios-pseudosigned и поставь через Sideloadly.
   Старую версию приложения лучше удалить перед установкой.

Что изменено:
- Список чатов в стиле MAX (chat_list_screen.dart, chat_preview_line.dart)
- Цвет по умолчанию #6547FF (main.dart, appearance_screen.dart)
- Иконка приложения: ios/Runner/Assets.xcassets/AppIcon.appiconset (все размеры)
- Логотипы в приложении: assets/komet.png, assets/komet_icon.png
- Название под иконкой: ios/Runner/Info.plist (CFBundleDisplayName, CFBundleName = MAX)
- Название в интерфейсе: заголовок входа, "Устройства в MAX", вкладка настроек, заголовок приложения (lib/l10n/*, main.dart, settings_tab.dart, komet_settings_screen.dart)

Не менялось: Bundle ID (ru.komet.app), иконки Android/macOS/Windows.
